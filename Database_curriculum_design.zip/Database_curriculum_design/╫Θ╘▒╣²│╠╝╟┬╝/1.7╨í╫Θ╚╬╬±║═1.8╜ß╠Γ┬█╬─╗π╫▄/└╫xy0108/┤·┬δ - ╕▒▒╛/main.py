# import connection
import pandas as pd
# from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import roc_curve, auc
# , RocCurveDisplay
import matplotlib.pyplot as plt                                         

if __name__ == '__main__':

    '''db = connection.Datab()  #与数据库建立连接
    data = db.search_execute("select * from merge_train_demo_useful")
    # 将数据转换为pandas DataFrame
    df = pd.DataFrame(data, columns=['User_id', 'Merchant_id', 'Coupon_id', 'Discount_rate', 'Distance', 'Date_received', 'original_table', 'result'])
    '''

    '''
    # 随机划分数据集(AUC值极高0.98-0.99)
    # 将Mysql中的数据表导出，并使用pandas读取
    df = pd.read_csv('C:\\Users\\25761\\Desktop\\数据库课设\\代码\\table\\merge_train_demo_useful.csv')
    # 准备数据（特征和目标都是数值型）
    X = df[['User_id', 'Merchant_id', 'Coupon_id', 'Discount_rate', 'Distance', 'Date_received', 'original_table']]
    y = df['result']
    # 划分训练集和测试集
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.4, random_state=42)  # 随机状态，随机状态相同则数据集的划分相同
    '''
    '''
    # 数据集按月划分(1-4预测5-6，带脏数据)(AUC下降明显0.774)
        df_train = pd.read_csv(
            'C:\\Users\\25761\\Desktop\\数据库课设\\代码\\table\\merge_train_v1_train.csv')  # 1-4月数据，训练集
        df_test = pd.read_csv('C:\\Users\\25761\\Desktop\\数据库课设\\代码\\table\\merge_train_v1_test.csv')  # 5-6月数据，测试集
    '''
    '''
    # 数据集按月划分(1-4预测5-6，清洗数据)
    df_train = pd.read_csv(
        'C:\\Users\\25761\\Desktop\\数据库课设\\代码\\table\\merge_train_demo_train_14_56.csv')  # 1-4月数据，训练集
    df_test = pd.read_csv('C:\\Users\\25761\\Desktop\\数据库课设\\代码\\table\\merge_train_demo_test_14_56.csv')  # 5-6月数据，测试集
    X_train = df_train[
        ['User_id', 'Merchant_id', 'Coupon_id', 'Discount_rate', 'Distance', 'Date_received', 'original_table']]
    y_train = df_train['result']
    X_test = df_test[
        ['User_id', 'Merchant_id', 'Coupon_id', 'Discount_rate', 'Distance', 'Date_received', 'original_table']]
    y_test = df_test['result']
    '''

    # 数据集按月划分(1-5预测6，已清洗)
    df_train = pd.read_csv('C:\\Users\\lxy55\\Desktop\\代码\\Kmeans_random\\merge_train_demo_train.csv')  # 1-5月数据，训练集
    df_test = pd.read_csv('C:\\Users\\lxy55\\Desktop\\代码\\Kmeans_random\\merge_train_demo_test.csv')  # 6月数据，测试集
    # 调整（观察特征中去除Coupon_id后的AUC，与去除前的AUC值相差不大）
    # 调整（观察特征中去除original_table后的AUC，与去除前的AUC值相差不大）
    X_train = df_train[['User_id', 'Merchant_id', 'Coupon_id', 'Discount_rate', 'Distance', 'Date_received', 'original_table']]
    y_train = df_train['result']
    X_test = df_test[['User_id', 'Merchant_id', 'Coupon_id', 'Discount_rate', 'Distance', 'Date_received', 'original_table']]
    y_test = df_test['result']

    # 创建并训练随机森林模型
    # clf = RandomForestClassifier(n_estimators=100, max_depth=200, min_samples_split=20, min_samples_leaf=5, max_features=3)  # 随机划分测试集和训练集的优秀参数
    clf = RandomForestClassifier(n_estimators=40,max_depth=20,min_samples_split=100,min_samples_leaf=40,max_features=3)  # 随机森林调参
    clf.fit(X_train, y_train)  # 训练模型

    # 预测测试集的分类结果
    '''y_pred = clf.predict(X_test)'''

    # 预测测试集的分类概率
    y_pred_proba = clf.predict_proba(X_test)
    y_true_proba = y_pred_proba[:,1]  # 取第二列

    # 计算ROC曲线和AUC值
    fpr, tpr, thresholds = roc_curve(y_test, y_true_proba)
    auc_value = auc(fpr, tpr)

    # 绘制ROC曲线-方法1
    '''roc_display = RocCurveDisplay(fpr = fpr,tpr = tpr, roc_auc=auc_value )
    roc_display.plot()
    plt.show()
    print('%.6f'%auc_value)'''

    # 绘制ROC曲线-方法2
    plt.figure()
    plt.plot(fpr, tpr, color='darkorange', lw=2, label='ROC curve (AUC = %0.6f)' % auc_value)
    plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
    plt.xlim([-0.05, 1.05])
    plt.ylim([-0.05, 1.05])
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('Coupon')
    plt.legend(loc="lower right")
    plt.show()

    # 提取随机森林的特征
    '''importances = clf.feature_importances_
    plt.bar(X.columns.tolist(), importances)
    plt.xlabel("Features")  
    plt.ylabel("Importance")  
    plt.title("Feature Importances")  
    plt.show()'''