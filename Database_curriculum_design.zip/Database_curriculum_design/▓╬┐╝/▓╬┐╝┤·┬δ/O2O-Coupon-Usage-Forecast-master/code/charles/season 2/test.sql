-- drop table if exists o2o_result;
-- create table o2o_result as select * from charles_gbdt_submission_4;

drop table if exists o2o_result;
create table o2o_result as select * from charles_xgb_submission_new_1;
	
-- drop table if exists o2o_result;
-- create table o2o_result as select * from charles_gbdt_submission_5;

-- drop table if exists o2o_result;
-- create table o2o_result as select * from charles_rf_submission_2;

-- drop table if exists o2o_result;
-- create table o2o_result as select * from charles_xgb_submission_8;

-- drop table if exists o2o_result;
-- create table o2o_result as select * from charles_xgb_submission_all_1;

