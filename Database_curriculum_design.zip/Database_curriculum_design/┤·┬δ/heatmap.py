# -*-coding:utf-8 -*-

"""
# File       : heatmap.py
# Time       ：2024/1/8 14:55
# Author     ：丁笠峰
# version    ：python 3.9
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

if __name__ == '__main__':
    #读入CSV文件
    df_train = pd.read_csv('C:\\Users\\25761\\Desktop\\数据库课设\\代码\\table\\merge_train_demo_train.csv')

    # 相关关系图(热力图)绘制
    corr_matrix = df_train.corr()
    plt.rcParams['axes.unicode_minus'] = False  # 确保负号显示正常
    plt.figure(figsize=(20,16))
    sns.heatmap(corr_matrix ,square=True,annot=True,fmt='.2f',mask = np.triu(corr_matrix))  # 热力图
    plt.xticks(fontsize=8)
    plt.yticks(fontsize=8)
    plt.show()