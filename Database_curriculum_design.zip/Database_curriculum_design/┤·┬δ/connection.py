# -*-coding:utf-8 -*-

"""
# File       : connection.py
# Time       ：2023/12/12 19:56
# Author     ：丁笠峰
# version    ：python 3.9
"""
import pymysql

#数据库交互类
class Datab:
    def __init__(self):
        self.Datab_connect = pymysql.connect(host='localhost', port=3306, charset='utf8',
                                             database='sql_for_coupons', password='20010610', user='root')
        self.DBC = self.Datab_connect.cursor()  # 开启游标功能，逐行进行数据操作

    def common_execute(self, command):
        try:
            self.DBC.execute(command)
            self.Datab_connect.commit()       # 提交修改
            return 1
        except Exception as error:
            self.Datab_connect.rollback()         # 返回上一条修改
            print("SQL错误：", error)
            return 0

    def search_execute(self, command):
        try:
            self.DBC.execute(command)
            data = self.DBC.fetchall()
            return data
        except Exception as error:
            print("SQL错误：", error)
            return None

    def __del__(self):
        self.DBC.close()
        self.Datab_connect.close()