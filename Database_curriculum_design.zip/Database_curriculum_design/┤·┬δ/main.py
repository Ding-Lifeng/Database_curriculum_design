# import connection
import pandas as pd
# import numpy as np
# from sklearn.model_selection import train_test_split
from sklearn.model_selection import GridSearchCV
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import roc_curve, auc
# , RocCurveDisplay
import matplotlib.pyplot as plt
# from boruta import BorutaPy

if __name__ == '__main__':

    '''
    db = connection.Datab()  #与数据库建立连接
    data = db.search_execute("select * from merge_train_demo_useful")
    # 将数据转换为pandas DataFrame
    df = pd.DataFrame(data, columns=['User_id', 'Merchant_id', 'Coupon_id', 'Discount_rate', 'Distance', 'Date_received', 'original_table', 'result'])
    '''

    '''
    # 随机划分数据集(AUC值极高0.98-0.99)
    # 将Mysql中的数据表导出，并使用pandas读取
    df = pd.read_csv('C:\\Users\\25761\\Desktop\\数据库课设\\代码\\table\\merge_train_demo_useful.csv')
    # 准备数据（特征和目标都是数值型）
    X = df[['User_id', 'Merchant_id', 'Coupon_id', 'Discount_rate', 'Distance', 'Date_received', 'original_table']]
    y = df['result']
    # 划分训练集和测试集
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.4, random_state=42)  # 随机状态，随机状态相同则数据集的划分相同
    '''
    '''
    # 数据集按月划分(1-4预测5-6，带脏数据)(AUC下降明显0.774)
        df_train = pd.read_csv(
            'C:\\Users\\25761\\Desktop\\数据库课设\\代码\\table\\merge_train_v1_train.csv')  # 1-4月数据，训练集
        df_test = pd.read_csv('C:\\Users\\25761\\Desktop\\数据库课设\\代码\\table\\merge_train_v1_test.csv')  # 5-6月数据，测试集
    '''
    '''
    # 数据集按月划分(1-4预测5-6，清洗数据)（AUC下降明显，但与题目的数据集和测试集关系相差较大）
    df_train = pd.read_csv(
        'C:\\Users\\25761\\Desktop\\数据库课设\\代码\\table\\merge_train_demo_train_14_56.csv')  # 1-4月数据，训练集
    df_test = pd.read_csv('C:\\Users\\25761\\Desktop\\数据库课设\\代码\\table\\merge_train_demo_test_14_56.csv')  # 5-6月数据，测试集
    X_train = df_train[
        ['User_id', 'Merchant_id', 'Coupon_id', 'Discount_rate', 'Distance', 'Date_received', 'original_table']]
    y_train = df_train['result']
    X_test = df_test[
        ['User_id', 'Merchant_id', 'Coupon_id', 'Discount_rate', 'Distance', 'Date_received', 'original_table']]
    y_test = df_test['result']
    '''

    # 数据集按月划分(1-5预测6，已清洗)
    df_train = pd.read_csv('C:\\Users\\25761\\Desktop\\数据库课设\\代码\\table\\merge_train_demo_train.csv')  # 1-5月数据，训练集
    df_test = pd.read_csv('C:\\Users\\25761\\Desktop\\数据库课设\\代码\\table\\merge_train_demo_test.csv')  # 6月数据，测试集
    # # 尝试数据转换-给BorutaPy使用，但失败
    # df_train = pd.read_csv('C:\\Users\\25761\\Desktop\\数据库课设\\代码\\table\\merge_train_demo_train.csv', dtype=
    # {'User_id': np.int32, 'Merchant_id': np.int32, 'Coupon_id': np.int32, 'Discount_rate': np.int32, 'Distance': np.int32
    #     , 'Date_received': np.int32, 'original_table': np.int32, 'result': np.int32})  # 1-5月数据，训练集
    # df_test = pd.read_csv('C:\\Users\\25761\\Desktop\\数据库课设\\代码\\table\\merge_train_demo_test.csv', dtype=
    # {'User_id': np.int32, 'Merchant_id': np.int32, 'Coupon_id': np.int32, 'Discount_rate': np.int32, 'Distance': np.int32
    #     , 'Date_received': np.int32, 'original_table': np.int32, 'result': np.int32})  # 6月数据，测试集
    # 调整（观察特征中去除Coupon_id后的AUC，与去除前的AUC值相差不大）
    # 调整（观察特征中去除original_table后的AUC，与去除前的AUC值相差不大）
    X_train = df_train[['User_id', 'Merchant_id', 'Coupon_id', 'Discount_rate', 'Distance', 'Date_received', 'original_table']]
    y_train = df_train['result']
    X_test = df_test[['User_id', 'Merchant_id', 'Coupon_id', 'Discount_rate', 'Distance', 'Date_received', 'original_table']]
    y_test = df_test['result']


    # # 网格法
    # # 对n_estimators进行网格搜索
    # params = [
    #     {'n_estimators':[40, 60, 80, 100]},
    #     {'max_depth':[20,40,60,100]},
    #     {'max_features':[3,4]}
    # ]
    # gs_search = GridSearchCV(estimator=RandomForestClassifier(min_samples_split=1000,min_samples_leaf=400),param_grid=params,scoring='roc_auc')
    # gs_search.fit(X_train,y_train)
    # print("模型的最优参数：",gs_search.best_params_)
    # print("最优模型分数：",gs_search.best_score_)
    # # 网格法结果展示
    # for params,score in zip(gs_search.cv_results_['params'],gs_search.cv_results_['mean_test_score']):
    #     print(params,score)


    # 创建并训练随机森林模型
    clf = RandomForestClassifier(n_estimators=100,max_depth=40,min_samples_split=1000,min_samples_leaf=400,max_features=7)  # 随机森林调参
    clf.fit(X_train, y_train)  # 训练模型

    # # 数据转换 - 与预期不符，只能对列特征打分不能对组合特征打分（并且存在大量的BUG）
    # X = X_train.values
    # y = y_train.values
    # y = y.ravel()
    # # 特征选择（Boruta-筛选所有和因变量具有相关性的特征集合）
    # feature_selector = BorutaPy(clf,n_estimators='auto')
    # feature_selector.fit(X,y)
    # print(feature_selector.support_)
    # np.savetxt('C:\\Users\\25761\\Desktop\\数据库课设\\过程记录\\关键记录(12.19之后的记录)\\Boruta-精准投放\\feature_importance.txt',feature_selector.ranking_)

    # 预测测试集的分类结果
    '''y_pred = clf.predict(X_test)'''
    # 预测测试集的分类概率
    y_pred_proba = clf.predict_proba(X_test)
    y_true_proba = y_pred_proba[:,1]  # 取第二列
    # 计算ROC曲线和AUC值
    fpr, tpr, thresholds = roc_curve(y_test, y_true_proba)
    auc_value = auc(fpr, tpr)

    # 绘制ROC曲线-方法1
    '''roc_display = RocCurveDisplay(fpr = fpr,tpr = tpr, roc_auc=auc_value )
    roc_display.plot()
    plt.show()
    print('%.6f'%auc_value)'''
    # 绘制ROC曲线-方法2
    plt.figure()
    plt.plot(fpr, tpr, color='darkorange', lw=2, label='ROC curve (AUC = %0.6f)' % auc_value)
    plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
    plt.xlim([-0.05, 1.05])
    plt.ylim([-0.05, 1.05])
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('Coupon')
    plt.legend(loc="lower right")
    plt.show()


